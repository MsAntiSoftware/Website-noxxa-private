# Project memory

## Product intent & audience

- Noxa AI: chat website where users converse with an AI using a user-provided API key
- Vite + React stack (JSX, Tailwind, Lucide React, `@/` alias) per project conventions
- Production-grade, fully-featured UI expected

## Brand personality & voice

- "Really fancy" — ornate, premium, eye-catching over minimal/cookie-cutter
- Dark purple aesthetic; glow/spotlight effects

## Visual design & UX direction

- Dark purple theme throughout
- Cursor-following glow/spotlight effect
- Slowly drifting animated background
- Animated greeting
- AI replies render rich formatting: bold, lists, code blocks; avoid raw math notation and stray asterisks
- Prefer depth, glows, and motion-based polish

## Decisions, constraints & rationale

- AI prompt updated to avoid raw math notation and bare asterisks in responses
- Response renderer supports markdown (bold, lists, code blocks)
- Theme switched to dark purple with mouse-tracked glow
- Rationale: user reported AI output showing raw math/asterisks; requested fancy purple with mouse-follow glow
- Build/type check pass; live browser visual verification still pending

## Open questions & assumptions

- Live browser visual check not yet performed — needs user confirmation
- API key flow/provider unspecified — assumed user-provided key entry exists
- Markdown rendering approach not confirmed