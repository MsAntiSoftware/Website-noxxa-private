/*
# Create chat conversations and messages (NOXA AI)

1. New Tables
- `chat_conversations`: one row per chat thread shown in the sidebar.
  - `id` (uuid, primary key)
  - `title` (text, not null, short label taken from the first question)
  - `created_at` / `updated_at` (timestamps)
- `chat_messages`: every user and assistant message inside a conversation.
  - `id` (uuid, primary key)
  - `conversation_id` (uuid, references chat_conversations, deleted with its conversation)
  - `role` (text, either 'user' or 'assistant')
  - `content` (text, not null)
  - `created_at` (timestamp)

2. Security
- Row level security enabled on both tables.
- The app has no sign-in, so the anon and authenticated roles get the policies.
- Access is granted only for the verbs the app uses (messages are never updated).

3. Notes
- Indexes on conversation lookups and message ordering.
- No existing data is changed.
*/

CREATE TABLE IF NOT EXISTS chat_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'New chat',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chat_conversations_updated_at_idx ON chat_conversations (updated_at DESC);
CREATE INDEX IF NOT EXISTS chat_messages_conversation_created_idx ON chat_messages (conversation_id, created_at);

ALTER TABLE chat_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON chat_conversations TO anon, authenticated;
GRANT SELECT, INSERT, DELETE ON chat_messages TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_chat_conversations" ON chat_conversations;
CREATE POLICY "anon_select_chat_conversations" ON chat_conversations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_chat_conversations" ON chat_conversations;
CREATE POLICY "anon_insert_chat_conversations" ON chat_conversations FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_chat_conversations" ON chat_conversations;
CREATE POLICY "anon_update_chat_conversations" ON chat_conversations FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_chat_conversations" ON chat_conversations;
CREATE POLICY "anon_delete_chat_conversations" ON chat_conversations FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_chat_messages" ON chat_messages;
CREATE POLICY "anon_select_chat_messages" ON chat_messages FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_chat_messages" ON chat_messages;
CREATE POLICY "anon_insert_chat_messages" ON chat_messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_chat_messages" ON chat_messages;
CREATE POLICY "anon_delete_chat_messages" ON chat_messages FOR DELETE
  TO anon, authenticated USING (true);
