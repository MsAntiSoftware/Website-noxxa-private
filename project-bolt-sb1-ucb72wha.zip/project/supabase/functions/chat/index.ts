const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
const MODEL = "openai/gpt-oss-120b";
const MAX_MESSAGES = 40;
const MAX_CONTENT_LENGTH = 8000;

const SYSTEM_PROMPT = [
  "You are NOXA AI, a helpful, friendly and precise assistant. Answer clearly and say so when you are unsure.",
  "Formatting rules: use only **bold**, bullet lists, numbered lists, `inline code`, and fenced code blocks.",
  "Never use LaTeX or math delimiters such as \\[ \\], \\( \\), $, or \\frac. Write math in plain text, for example: 2x + 30 = 43, so 2x = 13, so x = 6.5.",
].join("\n");

type ChatMessage = { role: "user" | "assistant"; content: string };

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function parseMessages(input: unknown): ChatMessage[] | null {
  if (!Array.isArray(input) || input.length === 0 || input.length > MAX_MESSAGES) return null;
  const messages: ChatMessage[] = [];
  for (const item of input) {
    if (!item || typeof item !== "object") return null;
    const { role, content } = item as Record<string, unknown>;
    if (role !== "user" && role !== "assistant") return null;
    if (typeof content !== "string" || content.trim().length === 0) return null;
    if (content.length > MAX_CONTENT_LENGTH) return null;
    messages.push({ role, content });
  }
  if (messages[messages.length - 1].role !== "user") return null;
  return messages;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("GROQ_API_KEY");
    if (!apiKey) {
      return jsonResponse({ error: "The AI service is not configured yet." }, 500);
    }

    const body = await req.json().catch(() => null);
    const messages = parseMessages(body?.messages);
    if (!messages) {
      return jsonResponse({ error: "Invalid chat request." }, 400);
    }

    const groqResponse = await fetch(GROQ_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
        temperature: 0.7,
        max_tokens: 2048,
      }),
    });

    if (!groqResponse.ok) {
      console.error("Groq request failed", groqResponse.status, await groqResponse.text());
      return jsonResponse({ error: "The AI service could not answer right now. Please try again." }, 502);
    }

    const data = await groqResponse.json();
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || reply.length === 0) {
      return jsonResponse({ error: "The AI service returned an empty answer." }, 502);
    }

    return jsonResponse({ reply });
  } catch (err) {
    console.error("chat function error", err);
    return jsonResponse({ error: "Something went wrong. Please try again." }, 500);
  }
});
