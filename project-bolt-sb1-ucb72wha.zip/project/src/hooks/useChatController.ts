import { useCallback, useEffect, useRef, useState } from 'react';
import {
  addMessage,
  createConversation,
  deleteConversation,
  fetchConversations,
  fetchMessages,
  requestReply,
  touchConversation,
} from '@/lib/chatService';
import type { ChatConversation, ChatMessage } from '@/types/chat';

const TITLE_MAX_LENGTH = 48;

interface ReplyRequest {
  conversationId: string;
  history: ChatMessage[];
}

function makeTitle(text: string): string {
  const singleLine = text.replace(/\s+/g, ' ').trim();
  return singleLine.length > TITLE_MAX_LENGTH
    ? `${singleLine.slice(0, TITLE_MAX_LENGTH - 1)}…`
    : singleLine;
}

function sortByRecent(list: ChatConversation[]): ChatConversation[] {
  return [...list].sort((a, b) => b.updated_at.localeCompare(a.updated_at));
}

export function useChatController() {
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoadingList, setIsLoadingList] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pendingReply, setPendingReply] = useState<ReplyRequest | null>(null);
  const activeIdRef = useRef<string | null>(null);

  const setActive = useCallback((id: string | null) => {
    activeIdRef.current = id;
    setActiveId(id);
  }, []);

  const appendIfActive = useCallback((conversationId: string, message: ChatMessage) => {
    if (activeIdRef.current === conversationId) {
      setMessages((prev) => [...prev, message]);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    setIsLoadingList(true);
    fetchConversations()
      .then((list) => {
        if (!cancelled) setConversations(list);
      })
      .catch(() => {
        if (!cancelled) setError("Couldn't load your chats. Please refresh the page.");
      })
      .finally(() => {
        if (!cancelled) setIsLoadingList(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const requestAssistantReply = useCallback(
    async (request: ReplyRequest) => {
      setIsSending(true);
      setError(null);
      setPendingReply(null);

      let saved: ChatMessage;
      try {
        const reply = await requestReply(
          request.history.map(({ role, content }) => ({ role, content })),
        );
        saved = await addMessage(request.conversationId, 'assistant', reply);
      } catch (err) {
        setPendingReply(request);
        setError(
          err instanceof Error && err.message.length > 0 && !err.message.startsWith('Request failed')
            ? err.message
            : 'NOXA AI could not answer right now. Please try again.',
        );
        setIsSending(false);
        return;
      }

      appendIfActive(request.conversationId, saved);

      const updatedAt = new Date().toISOString();
      setConversations((prev) =>
        sortByRecent(
          prev.map((c) => (c.id === request.conversationId ? { ...c, updated_at: updatedAt } : c)),
        ),
      );
      touchConversation(request.conversationId, updatedAt).catch(() => undefined);

      setIsSending(false);
    },
    [appendIfActive],
  );

  const selectConversation = useCallback(
    async (id: string) => {
      if (id === activeIdRef.current) return;
      setActive(id);
      setMessages([]);
      setError(null);
      setIsLoadingMessages(true);
      try {
        const loaded = await fetchMessages(id);
        if (activeIdRef.current === id) setMessages(loaded);
      } catch {
        if (activeIdRef.current === id) setError("Couldn't load this chat.");
      } finally {
        if (activeIdRef.current === id) setIsLoadingMessages(false);
      }
    },
    [setActive],
  );

  const startNewChat = useCallback(() => {
    setActive(null);
    setMessages([]);
    setError(null);
  }, [setActive]);

  const sendMessage = useCallback(
    async (rawText: string): Promise<boolean> => {
      const text = rawText.trim();
      if (!text || isSending) return false;

      setIsSending(true);
      setError(null);
      setPendingReply(null);

      let conversationId: string;
      let userMessage: ChatMessage;
      try {
        if (activeIdRef.current) {
          conversationId = activeIdRef.current;
        } else {
          const created = await createConversation(makeTitle(text));
          conversationId = created.id;
          setConversations((prev) => [created, ...prev]);
          setActive(created.id);
        }
        userMessage = await addMessage(conversationId, 'user', text);
      } catch {
        setError("Your message couldn't be sent. Please try again.");
        setIsSending(false);
        return false;
      }

      appendIfActive(conversationId, userMessage);
      void requestAssistantReply({
        conversationId,
        history: [...messages, userMessage],
      });
      return true;
    },
    [isSending, messages, appendIfActive, requestAssistantReply, setActive],
  );

  const retryReply = useCallback(() => {
    if (pendingReply && !isSending) void requestAssistantReply(pendingReply);
  }, [pendingReply, isSending, requestAssistantReply]);

  const removeConversation = useCallback(
    async (id: string) => {
      try {
        await deleteConversation(id);
      } catch {
        setError("Couldn't delete this chat. Please try again.");
        return;
      }
      setConversations((prev) => prev.filter((c) => c.id !== id));
      if (activeIdRef.current === id) startNewChat();
      setPendingReply((prev) => (prev?.conversationId === id ? null : prev));
    },
    [startNewChat],
  );

  return {
    conversations,
    activeId,
    messages,
    isLoadingList,
    isLoadingMessages,
    isSending,
    error,
    canRetry: pendingReply !== null && pendingReply.conversationId === activeId,
    selectConversation,
    startNewChat,
    sendMessage,
    retryReply,
    removeConversation,
  };
}
