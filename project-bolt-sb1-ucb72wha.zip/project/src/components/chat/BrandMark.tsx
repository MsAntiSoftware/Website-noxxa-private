import { Sparkles } from 'lucide-react';

export default function BrandMark() {
  return (
    <div className="flex items-center gap-2.5">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white shadow-[0_0_24px_-4px_rgba(139,92,246,0.9)]">
        <Sparkles size={17} strokeWidth={2.25} />
      </span>
      <span className="text-base font-semibold tracking-tight text-white">NOXA AI</span>
    </div>
  );
}
