import { Sparkles } from 'lucide-react';
import MarkdownText from '@/components/chat/MarkdownText';
import type { ChatMessage } from '@/types/chat';

export function AssistantAvatar() {
  return (
    <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white shadow-[0_0_20px_-4px_rgba(139,92,246,0.8)]">
      <Sparkles size={16} />
    </span>
  );
}

export default function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === 'user';

  return (
    <div className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {!isUser && <AssistantAvatar />}
      <div
        className={`max-w-[85%] break-words rounded-2xl px-4 py-3 text-[15px] leading-[1.6] shadow-lg sm:max-w-[75%] ${
          isUser
            ? 'whitespace-pre-wrap rounded-br-md bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white shadow-violet-900/40'
            : 'rounded-bl-md border border-white/10 bg-white/[0.04] text-neutral-100 backdrop-blur-xl'
        }`}
      >
        {isUser ? message.content : <MarkdownText source={message.content} />}
      </div>
    </div>
  );
}
