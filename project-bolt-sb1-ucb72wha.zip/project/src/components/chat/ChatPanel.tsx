import { AlertCircle, Menu } from 'lucide-react';
import Composer from '@/components/chat/Composer';
import MessageList from '@/components/chat/MessageList';
import type { ChatMessage } from '@/types/chat';

interface ChatPanelProps {
  title: string;
  messages: ChatMessage[];
  isLoadingMessages: boolean;
  isSending: boolean;
  error: string | null;
  canRetry: boolean;
  onRetry: () => void;
  onSend: (text: string) => Promise<boolean>;
  onOpenSidebar: () => void;
}

export default function ChatPanel({
  title,
  messages,
  isLoadingMessages,
  isSending,
  error,
  canRetry,
  onRetry,
  onSend,
  onOpenSidebar,
}: ChatPanelProps) {
  return (
    <section className="flex min-h-0 min-w-0 flex-1 flex-col">
      <header className="flex h-14 shrink-0 items-center gap-3 border-b border-white/10 bg-neutral-950/40 px-4 backdrop-blur-xl">
        <button
          type="button"
          onClick={onOpenSidebar}
          aria-label="Open sidebar"
          className="rounded-lg p-1.5 text-neutral-200 transition hover:bg-white/10 md:hidden"
        >
          <Menu size={20} />
        </button>
        <h1 className="truncate text-sm font-semibold text-white">{title}</h1>
      </header>

      <div className="min-h-0 flex-1 overflow-y-auto">
        <MessageList
          messages={messages}
          isLoading={isLoadingMessages}
          isSending={isSending}
          onSuggest={(text) => void onSend(text)}
        />
      </div>

      <div className="shrink-0 border-t border-white/10 bg-neutral-950/40 px-4 pb-4 pt-3 backdrop-blur-xl sm:px-6">
        {error && (
          <div
            role="alert"
            className="mx-auto mb-3 flex w-full max-w-3xl items-center justify-between gap-3 rounded-xl border border-red-400/30 bg-red-500/10 px-4 py-3 text-sm text-red-100"
          >
            <span className="flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0 text-red-300" />
              {error}
            </span>
            {canRetry && (
              <button
                type="button"
                onClick={onRetry}
                disabled={isSending}
                className="shrink-0 font-semibold text-white underline underline-offset-2 transition hover:text-violet-200 disabled:opacity-50"
              >
                Try again
              </button>
            )}
          </div>
        )}
        <Composer disabled={isSending} onSend={onSend} />
      </div>
    </section>
  );
}
