import { useEffect, useRef } from 'react';
import { Loader2 } from 'lucide-react';
import EmptyState from '@/components/chat/EmptyState';
import MessageBubble, { AssistantAvatar } from '@/components/chat/MessageBubble';
import type { ChatMessage } from '@/types/chat';

interface MessageListProps {
  messages: ChatMessage[];
  isLoading: boolean;
  isSending: boolean;
  onSuggest: (text: string) => void;
}

export default function MessageList({ messages, isLoading, isSending, onSuggest }: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length, isSending]);

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center text-violet-300">
        <Loader2 size={24} className="animate-spin" />
      </div>
    );
  }

  if (messages.length === 0 && !isSending) {
    return <EmptyState onSuggest={onSuggest} />;
  }

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-6 sm:px-6">
      {messages.map((message) => (
        <div key={message.id} className="animate-fade-up">
          <MessageBubble message={message} />
        </div>
      ))}

      {isSending && (
        <div className="flex gap-3">
          <AssistantAvatar />
          <div
            className="flex items-center gap-1.5 rounded-2xl rounded-bl-md border border-white/10 bg-white/[0.04] px-4 py-4 backdrop-blur-xl"
            role="status"
            aria-label="NOXA AI is typing"
          >
            <span className="h-2 w-2 animate-bounce rounded-full bg-violet-300 [animation-delay:-0.3s]" />
            <span className="h-2 w-2 animate-bounce rounded-full bg-violet-300 [animation-delay:-0.15s]" />
            <span className="h-2 w-2 animate-bounce rounded-full bg-violet-300" />
          </div>
        </div>
      )}

      <div ref={bottomRef} />
    </div>
  );
}
