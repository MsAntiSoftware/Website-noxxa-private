import { ArrowUpRight } from 'lucide-react';
import BrandMark from '@/components/chat/BrandMark';

const SUGGESTIONS = [
  'Explain a complex idea in simple terms',
  'Draft a friendly email to my team',
  'Help me plan a weekend in the mountains',
  'Brainstorm names for a small coffee shop',
];

interface EmptyStateProps {
  onSuggest: (text: string) => void;
}

export default function EmptyState({ onSuggest }: EmptyStateProps) {
  return (
    <div className="flex h-full flex-col items-center justify-center px-6 py-10 text-center">
      <div className="animate-fade-up">
        <BrandMark />
      </div>
      <h2 className="animate-fade-up mt-8 text-3xl font-semibold leading-[1.2] tracking-tight text-white sm:text-4xl [animation-delay:80ms]">
        How can I <span className="gradient-text">help you</span> today?
      </h2>
      <p className="animate-fade-up mt-4 max-w-md text-[15px] leading-[1.6] text-neutral-300 [animation-delay:160ms]">
        Ask NOXA AI anything, from quick questions to longer projects. Your chats are saved in the
        sidebar.
      </p>

      <div className="mt-10 grid w-full max-w-2xl gap-3 sm:grid-cols-2">
        {SUGGESTIONS.map((suggestion, index) => (
          <button
            key={suggestion}
            type="button"
            onClick={() => onSuggest(suggestion)}
            style={{ animationDelay: `${240 + index * 70}ms` }}
            className="animate-fade-up group flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3.5 text-left text-sm text-neutral-100 backdrop-blur-xl transition duration-300 hover:-translate-y-0.5 hover:border-violet-400/50 hover:bg-violet-500/10 hover:shadow-[0_0_30px_-8px_rgba(139,92,246,0.7)]"
          >
            <span>{suggestion}</span>
            <ArrowUpRight
              size={16}
              className="shrink-0 text-neutral-400 transition group-hover:text-violet-300"
            />
          </button>
        ))}
      </div>
    </div>
  );
}
