import { Loader2, MessageSquare, Plus, Trash2, X } from 'lucide-react';
import BrandMark from '@/components/chat/BrandMark';
import type { ChatConversation } from '@/types/chat';

interface SidebarProps {
  conversations: ChatConversation[];
  activeId: string | null;
  isLoading: boolean;
  isOpen: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  onDelete: (id: string) => void;
}

export default function Sidebar({
  conversations,
  activeId,
  isLoading,
  isOpen,
  onClose,
  onSelect,
  onNewChat,
  onDelete,
}: SidebarProps) {
  return (
    <>
      <div
        onClick={onClose}
        aria-hidden="true"
        className={`fixed inset-0 z-30 bg-neutral-950/70 backdrop-blur-sm transition-opacity duration-300 md:hidden ${
          isOpen ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      />
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-white/10 bg-neutral-950/80 backdrop-blur-2xl transition-transform duration-300 ease-out md:static md:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between px-5 pb-5 pt-5">
          <BrandMark />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close sidebar"
            className="rounded-lg p-1.5 text-neutral-400 transition hover:bg-white/10 hover:text-white md:hidden"
          >
            <X size={20} />
          </button>
        </div>

        <div className="px-4 pb-5">
          <button
            type="button"
            onClick={onNewChat}
            className="group flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-violet-900/40 transition hover:shadow-violet-700/60 hover:brightness-110 active:scale-[0.98]"
          >
            <Plus size={16} strokeWidth={2.5} className="transition group-hover:rotate-90" />
            New chat
          </button>
        </div>

        <p className="px-5 pb-2 text-xs font-medium uppercase tracking-wider text-neutral-400">
          Recent
        </p>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 pb-4">
          {isLoading && (
            <div className="flex items-center gap-2 px-3 py-2 text-sm text-neutral-400">
              <Loader2 size={16} className="animate-spin" />
              Loading chats...
            </div>
          )}

          {!isLoading && conversations.length === 0 && (
            <p className="px-3 py-2 text-sm text-neutral-400">No chats yet. Start one above.</p>
          )}

          {conversations.map((conversation) => {
            const isActive = conversation.id === activeId;
            return (
              <div
                key={conversation.id}
                className={`group flex items-center gap-1 rounded-lg pr-1 transition ${
                  isActive
                    ? 'bg-white/10 shadow-[inset_2px_0_0_0_rgb(167,139,250)]'
                    : 'hover:bg-white/5'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelect(conversation.id)}
                  className="flex min-w-0 flex-1 items-center gap-3 px-3 py-2.5 text-left text-sm"
                >
                  <MessageSquare
                    size={16}
                    className={`shrink-0 ${isActive ? 'text-violet-300' : 'text-neutral-400'}`}
                  />
                  <span className={`truncate ${isActive ? 'text-white' : 'text-neutral-200'}`}>
                    {conversation.title}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => onDelete(conversation.id)}
                  aria-label={`Delete chat: ${conversation.title}`}
                  className="rounded-md p-1.5 text-neutral-400 opacity-100 transition hover:bg-white/10 hover:text-red-300 focus-visible:opacity-100 md:opacity-0 md:group-hover:opacity-100"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            );
          })}
        </nav>
      </aside>
    </>
  );
}
