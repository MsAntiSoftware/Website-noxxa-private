import { useState } from 'react';
import { Send } from 'lucide-react';

interface ComposerProps {
  disabled: boolean;
  onSend: (text: string) => Promise<boolean>;
}

export default function Composer({ disabled, onSend }: ComposerProps) {
  const [value, setValue] = useState('');
  const canSend = value.trim().length > 0 && !disabled;

  const submit = async () => {
    if (!canSend) return;
    const text = value;
    setValue('');
    const sent = await onSend(text);
    if (!sent) setValue((current) => current || text);
  };

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        void submit();
      }}
      className="mx-auto w-full max-w-3xl"
    >
      <div className="flex items-end gap-2 rounded-2xl border border-white/10 bg-white/[0.05] p-2 shadow-2xl shadow-black/40 backdrop-blur-xl transition focus-within:border-violet-400/60 focus-within:shadow-[0_0_30px_-6px_rgba(139,92,246,0.6)]">
        <textarea
          rows={1}
          value={value}
          maxLength={8000}
          onChange={(event) => setValue(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
              event.preventDefault();
              void submit();
            }
          }}
          placeholder="Message NOXA AI..."
          aria-label="Message NOXA AI"
          className="max-h-40 min-h-[40px] flex-1 resize-none bg-transparent px-2 py-2 text-[15px] leading-[1.5] text-neutral-100 placeholder:text-neutral-400 focus:outline-none"
        />
        <button
          type="submit"
          disabled={!canSend}
          aria-label="Send message"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white shadow-lg shadow-violet-900/50 transition hover:brightness-110 active:scale-95 disabled:cursor-not-allowed disabled:bg-none disabled:bg-white/10 disabled:text-neutral-400 disabled:shadow-none"
        >
          <Send size={18} />
        </button>
      </div>
      <p className="mt-2 text-center text-xs text-neutral-400">
        NOXA AI can make mistakes. Check important information.
      </p>
    </form>
  );
}
