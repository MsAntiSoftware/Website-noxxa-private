import { SUPABASE_ANON_KEY, SUPABASE_URL, supabase } from '@/lib/supabase';
import type { ChatConversation, ChatMessage, MessageRole } from '@/types/chat';

const CONVERSATION_COLUMNS = 'id, title, created_at, updated_at';
const MESSAGE_COLUMNS = 'id, conversation_id, role, content, created_at';

export async function fetchConversations(): Promise<ChatConversation[]> {
  const { data, error } = await supabase
    .from('chat_conversations')
    .select(CONVERSATION_COLUMNS)
    .order('updated_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function createConversation(title: string): Promise<ChatConversation> {
  const { data, error } = await supabase
    .from('chat_conversations')
    .insert({ title })
    .select(CONVERSATION_COLUMNS)
    .single();
  if (error) throw error;
  return data;
}

export async function touchConversation(id: string, updatedAt: string): Promise<void> {
  const { error } = await supabase
    .from('chat_conversations')
    .update({ updated_at: updatedAt })
    .eq('id', id);
  if (error) throw error;
}

export async function deleteConversation(id: string): Promise<void> {
  const { error } = await supabase.from('chat_conversations').delete().eq('id', id);
  if (error) throw error;
}

export async function fetchMessages(conversationId: string): Promise<ChatMessage[]> {
  const { data, error } = await supabase
    .from('chat_messages')
    .select(MESSAGE_COLUMNS)
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function addMessage(
  conversationId: string,
  role: MessageRole,
  content: string,
): Promise<ChatMessage> {
  const { data, error } = await supabase
    .from('chat_messages')
    .insert({ conversation_id: conversationId, role, content })
    .select(MESSAGE_COLUMNS)
    .single();
  if (error) throw error;
  return data;
}

export async function requestReply(
  messages: { role: MessageRole; content: string }[],
): Promise<string> {
  const response = await fetch(`${SUPABASE_URL}/functions/v1/chat`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      apikey: SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ messages }),
  });

  const payload: unknown = await response.json().catch(() => null);

  if (!response.ok) {
    const serverMessage =
      payload && typeof payload === 'object' && 'error' in payload && typeof payload.error === 'string'
        ? payload.error
        : null;
    throw new Error(serverMessage ?? `Request failed (${response.status})`);
  }

  if (!payload || typeof payload !== 'object' || !('reply' in payload) || typeof payload.reply !== 'string') {
    throw new Error('Unexpected response from the AI service.');
  }

  return payload.reply;
}
