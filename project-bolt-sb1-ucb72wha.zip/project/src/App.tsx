import { useState } from 'react';
import ChatPanel from '@/components/chat/ChatPanel';
import CursorGlow from '@/components/chat/CursorGlow';
import Sidebar from '@/components/chat/Sidebar';
import { useChatController } from '@/hooks/useChatController';

export default function App() {
  const chat = useChatController();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const activeTitle =
    chat.conversations.find((conversation) => conversation.id === chat.activeId)?.title ??
    'New chat';

  const handleSelect = (id: string) => {
    void chat.selectConversation(id);
    setIsSidebarOpen(false);
  };

  const handleNewChat = () => {
    chat.startNewChat();
    setIsSidebarOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this chat? This cannot be undone.')) {
      void chat.removeConversation(id);
    }
  };

  return (
    <div className="relative flex h-dvh overflow-hidden bg-neutral-950 font-sans text-neutral-100 antialiased">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="animate-float-slow absolute -left-32 -top-32 h-[28rem] w-[28rem] rounded-full bg-violet-600/25 blur-[120px]" />
        <div
          className="animate-float-slow absolute -bottom-40 right-[-8rem] h-[32rem] w-[32rem] rounded-full bg-fuchsia-600/20 blur-[140px]"
          style={{ animationDelay: '-6s' }}
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.05)_1px,transparent_0)] [background-size:24px_24px]" />
      </div>

      <div className="relative z-10 flex min-h-0 flex-1">
        <Sidebar
          conversations={chat.conversations}
          activeId={chat.activeId}
          isLoading={chat.isLoadingList}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          onSelect={handleSelect}
          onNewChat={handleNewChat}
          onDelete={handleDelete}
        />
        <ChatPanel
          title={activeTitle}
          messages={chat.messages}
          isLoadingMessages={chat.isLoadingMessages}
          isSending={chat.isSending}
          error={chat.error}
          canRetry={chat.canRetry}
          onRetry={chat.retryReply}
          onSend={chat.sendMessage}
          onOpenSidebar={() => setIsSidebarOpen(true)}
        />
      </div>

      <CursorGlow />
    </div>
  );
}
